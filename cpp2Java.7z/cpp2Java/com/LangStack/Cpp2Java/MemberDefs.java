package com.LangStack.Cpp2Java;

public class MemberDefs {

}
