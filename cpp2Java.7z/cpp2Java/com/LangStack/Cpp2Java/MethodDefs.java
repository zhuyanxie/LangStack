package com.LangStack.Cpp2Java;

import java.util.ArrayList;
import java.util.List;

public class MethodDefs {
    private String        mClassName;
    private String        mMethodName;
    private boolean       mIsStatic;
    private List<Method>  mParams     = new ArrayList<Method>();    ///< 第一个参数为retval
    private TypeDefs      mTypes      = null;
    
    class Method 
    {
        public String getParam() {
            return mParam;
        }
        public void setParam(String param) {
            this.mParam = param;
        }
        public int getType() {
            return mType;
        }
        public String getName() {
            return mName;
        }
        public void setName(String name) {
            this.mName = name;
        }
        public boolean paramToType() {
            mType = mTypes.getType(mParam);
            return mType != TypeDefs.TYPE_UNKOWN;
        }
        
        private String  mParam;     ///< 参数类型字符串
        private int     mType;      ///< 类型定义@see TypeDefs
        private String  mName;      ///< 参数名
    }
   
    public MethodDefs(String className, String methodName, boolean isStatic) {
        mClassName = className;
        mMethodName = methodName;
        mIsStatic = isStatic;
    }
    
    public void addParam(String param, String name) {
        Method method = new Method();
        method.setParam(param);
        method.setName(name);
    }
    
    public boolean paramToType() {
        for (Method method : mParams) {
            if (!method.paramToType()) {
                return false;
            }
        }
        
        return true;
    }
}
